
-----------------------CONSULTA-1----------------------------------

--Obtener  los clientes con mas pedidos
SELECT Id_Cliente, COUNT(Id_Cliente) AS NumeroDePedidos
FROM pedido
GROUP BY Id_Cliente
ORDER BY NumeroDePedidos desc;


-- Consulta para obtener la  informaci�n de valor de los clientes con mas pedidos (su nombre, telefono y ciudad para env�o de promociones)

SELECT c.nombre_cliente, c.telefono, c.ciudad, p.NumeroDePedidos
FROM cliente c
JOIN (
    SELECT Id_Cliente, COUNT(Id_Cliente) AS NumeroDePedidos
    FROM pedido
    GROUP BY Id_Cliente
) p ON c.Id_Cliente = p.Id_Cliente
ORDER BY p.NumeroDePedidos DESC;

----------------------------------------CONSULTA-2-------------------------------------------------------------------

--Consulta que nos ayuda a ver los comentarios de los pedidos rechazados para atacar las fallas opeativas en las negociaciones o en la tienda

SELECT *
  FROM [jardineria].[dbo].[pedido] WHERE ESTADO = 'Rechazado' AND comentarios is not null




-----------------------------------CONSULTA-3----------------------------------------------------------------------------

-- Consulta donde obtenemos el total de empleados por oficina

SELECT o.ID_oficina AS id_oficina,
       o.Descripcion AS nombre_oficina,
       o.ciudad,
       o.pais,
       o.region,
       o.telefono,
       COUNT(e.ID_oficina) AS total_empleados
FROM oficina o
JOIN empleado e ON o.ID_oficina = e.ID_oficina
GROUP BY o.ID_oficina, o.Descripcion, o.ciudad, o.pais, o.region, o.telefono  
Order BY total_empleados Desc;


----------------------------------CONSULTA-4---------------------------------------

--Consulta para obtener la Cantidad de pedidos por oficina 

SELECT o.ID_oficina,
       o.Descripcion AS nombre_oficina, 
	   o.ciudad,
	   o.region ,
	   o.pais,
	   o.telefono,
       COUNT(p.ID_pedido) AS cantidad_pedidos
FROM oficina o
LEFT JOIN empleado e ON o.ID_oficina = e.ID_oficina
LEFT JOIN cliente c ON e.ID_empleado = c.ID_empleado_rep_ventas
LEFT JOIN pedido p ON c.ID_cliente = p.ID_cliente
GROUP BY o.ID_oficina, o.Descripcion, o.ciudad,  o.region , o.pais, o.telefono


---------------------------CONSULTA-5---------------------------------------

-- Consulta para saber el top 5 de los Empleados con mas pedidos en estado entregado.

Select top 5
e.ID_empleado,
e.nombre,
e.apellido1,
e.apellido2,
e.email,
e.puesto,
e.ID_oficina,
COUNT (p.ID_pedido) AS total_pedidos_entregados
FROM empleado e
join pedido p ON e.ID_empleado = p.ID_cliente
WHERE p.estado = 'entregado'
Group by
e.ID_empleado,
e.nombre,
e.apellido1,
e.apellido2,
e.email,
e.puesto,
e.ID_oficina
ORDER BY
total_pedidos_entregados DESC;


------------------------Consulta 6------------

----Pedidos completados por mes y a�o---------------

SELECT YEAR(fecha_pedido) AS a�o, MONTH(fecha_pedido) AS mes, COUNT(*) AS total_pedidos
FROM DBO.pedido
WHERE estado = 'entregado'
GROUP BY YEAR(fecha_pedido), MONTH(fecha_pedido)
ORDER BY a�o DESC, mes DESC;


-------------------CONSULTA 7-----------------------

----Consulta los productos que en el stock se tiene una cantidad menor o igual a 10.

SELECT * FROM  DBO.producto WHERE  cantidad_en_stock <= 10 ORDER BY cantidad_en_stock;


-----------------------------------Consulta 8--------------------------------------------------------

--------------Consultar cu�ntos productos hay en cada categor�a---------------


SELECT cp.Id_Categoria, cp.Desc_Categoria, COUNT(p.ID_producto) AS num_productos
FROM jardineria.dbo.Categoria_producto cp
LEFT JOIN jardineria.dbo.producto p ON cp.Id_Categoria = p.Categoria
GROUP BY cp.Id_Categoria, cp.Desc_Categoria;



-------------------------------------------------------------------------------------------

-----Query para evitar que se dupliquen los registros en las tablas de la BD stagin--------------
truncate table Destino_EmpleadosPorOficina
truncate table Destino_ClientesConMasPedidos
truncate table Destino_CantidadPedidosPorOficina
truncate table Destino_empleadosConMasPedidos
truncate table Destino_Ventas_Por_Anio_Mes
truncate table Destino_ProductoStockBajo
truncate table Destino_PedidosRechazadosConComentarios


